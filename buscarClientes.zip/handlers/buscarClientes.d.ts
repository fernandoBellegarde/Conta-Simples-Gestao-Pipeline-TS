export declare const handler: (event: any) => Promise<{
    statusCode: number;
    headers: {
        "Content-Type0": string;
        "Acess-Control-Allow-Origin": string;
        "Content-Type"?: never;
        "Access-Control-Allow-Origin"?: never;
    };
    body: string;
} | {
    statusCode: number;
    headers: {
        "Content-Type": string;
        "Access-Control-Allow-Origin": string;
        "Content-Type0"?: never;
        "Acess-Control-Allow-Origin"?: never;
    };
    body: string;
}>;
//# sourceMappingURL=buscarClientes.d.ts.map