export declare const handler: (event: any) => Promise<{
    statusCode: number;
    headers: {
        "Content-Type": string;
        "Access-Control-Allow-Origin": string;
    };
    body: string;
}>;
//# sourceMappingURL=deletarCliente.d.ts.map