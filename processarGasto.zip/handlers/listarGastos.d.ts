import type { APIGatewayProxyEvent } from "aws-lambda";
export declare const handler: (event: APIGatewayProxyEvent) => Promise<{
    statusCode: number;
    headers: {
        "Access-Control-Allow-Origin": string;
    };
    body: string;
}>;
//# sourceMappingURL=listarGastos.d.ts.map