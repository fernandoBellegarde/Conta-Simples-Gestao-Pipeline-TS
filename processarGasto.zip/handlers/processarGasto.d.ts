import type { SQSEvent } from "aws-lambda";
export declare const handler: (event: SQSEvent) => Promise<void>;
//# sourceMappingURL=processarGasto.d.ts.map